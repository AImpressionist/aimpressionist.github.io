# xuhuifan.github.io

To update an html, cd to the directory, then execute: python jemdoc.py index.jemdoc
Finally, add this html to this repository.
